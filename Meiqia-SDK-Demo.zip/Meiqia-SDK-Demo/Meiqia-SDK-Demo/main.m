//
//  main.m
//  Meiqia-SDK-Demo
//
//  Created by ijinmao on 15/12/9.
//  Copyright © 2015年 ijinmao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
