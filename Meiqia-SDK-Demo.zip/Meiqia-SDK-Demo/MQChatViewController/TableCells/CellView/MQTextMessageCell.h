//
//  MQTextMessageCell.h
//  MeiQiaSDK
//
//  Created by ijinmao on 15/10/29.
//  Copyright © 2015年 MeiQia Inc. All rights reserved.
//

#import "MQChatBaseCell.h"
#import "MQTextCellModel.h"
#import "TTTAttributedLabel.h"

/**
 * MQTextCell定义了客服聊天界面的文字消息cell
 */
@interface MQTextMessageCell : MQChatBaseCell 


@end
