//
//  MQChatRegexUtil.m
//  MQChatViewControllerDemo
//
//  Created by ijinmao on 15/11/1.
//  Copyright © 2015年 ijinmao. All rights reserved.
//

#import "MQChatRegexUtil.h"

@implementation MQChatRegexUtil

@end
