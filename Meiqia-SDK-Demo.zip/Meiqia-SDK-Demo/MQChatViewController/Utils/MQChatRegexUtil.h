//
//  MQChatRegexUtil.h
//  MQChatViewControllerDemo
//
//  Created by ijinmao on 15/11/1.
//  Copyright © 2015年 ijinmao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MQChatRegexUtil : NSObject

@end
