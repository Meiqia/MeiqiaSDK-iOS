//
//  MQChatEmojize.h
//  MQChatViewControllerDemo
//
//  Created by ijinmao on 15/11/23.
//  Copyright © 2015年 ijinmao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MQChatEmojize : NSObject

+ (BOOL)stringContainsEmoji:(NSString *)string;

@end
